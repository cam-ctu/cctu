library(testthat)
library(cctu)
library(readxl)
library(magrittr)
library(xml2)
library(dplyr)
test_check("cctu")

# desiderata

# check of using nonstandard paths for output.

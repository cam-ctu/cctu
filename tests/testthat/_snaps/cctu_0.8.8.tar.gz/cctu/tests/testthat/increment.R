print(environment())
print(x)
x <- x + 1

library(cctu)
getwd()
run_batch(normalizePath("script_to_test_run_batch.R"))

## ----eval=FALSE---------------------------------------------------------------
# write.csv(
#   get_meta_table(),
#   file=file.path("Output","meta_table.csv"), row.names = FALSE
# )

## ----eval=FALSE---------------------------------------------------------------
# # Copy the templates to the Progs folder under current working directory
# rmd_files <- list.files(system.file("assets/rmd", package = "cctu"),
#                         pattern = "*.Rmd",
#                         full.names = TRUE)
# file.copy(from = rmd_files,
#           to = "Progs",
#           overwrite = TRUE,
#           recursive = FALSE,
#           copy.mode = TRUE)

## ----eval=FALSE---------------------------------------------------------------
# rmarkdown::render(
#   # Path to the RMD template file
#   file.path("Progs", "rmarkdown_report.Rmd"),
#   # Name of the output file
#   output_file = "Vignette Report.html",
#   # Set the output directory to the Output/Reports folder
#   output_dir = file.path("Output", "Reports"),
#   # Set the working directory to the current working directory instead of the RMD file
#   knit_root_dir = getwd(),
#   params = list(
#     my_author = "Simon Bond",  # Name of the author
#     my_title = "Vignette Report" # Title of the report
#   )
# )

## ----eval=FALSE---------------------------------------------------------------
# file.copy(from = system.file("assets/qmd/quarto-report.qmd", package = "cctu"),
#           to = getwd(),
#           overwrite = TRUE,
#           recursive = FALSE,
#           copy.mode = TRUE)

## ----eval=FALSE---------------------------------------------------------------
# quarto::quarto_render(
#   input = "quarto-report.qmd", # Path to the QMD template file
#   # Name of the output file
#   output_file = "Vignette Report.html",
#   # Set the output format to HTML
#   output_format = "html",
#   # Params to be passed to the QMD file
#   execute_params = list(
#     my_author = "Simon Bond",
#     my_title = "Vignette Report",
#     tinny_table = TRUE # Use the tinny table format for the tables
#   )
# )


context("create_word_xml check not provided elswhere")


# Not sure if I want to actually change the wd and thus need to build all the input files...
# need to check lines 42:43
# if(getwd()!=path){
#  warning(paste("you are calling create_word_xml with the working directory not equal to", path))
#  setwd(path)
# }

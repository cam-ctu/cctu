write.csv(data.frame(x = 1:10), file = "batch_test.csv", row.names = FALSE)

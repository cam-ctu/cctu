print("Hello World")
library(cctu)
# run_batch("nested_run_batch.R")
run_batch("script_to_test_run_batch.R")

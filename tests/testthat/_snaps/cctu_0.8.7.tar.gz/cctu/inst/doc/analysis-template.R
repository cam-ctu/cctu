## ----setup, include = FALSE---------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----initial------------------------------------------------------------------
rm(list = ls())
# if using renv for extra packages need this line for R CMD BATCH
# renv::load()
library(cctu)
options(verbose = TRUE)
# run_batch("main.R")
DATA <- "PATH_TO_DATA"
cctu_initialise()
rm_output()

## ----echo=FALSE---------------------------------------------------------------
sourceKnit <- function(path, label) {
  cmd <- knitr::knit_expand(file.path("Progs", "_templ.Rmd"))
  knitr::knit_child(text = unlist(cmd))
}

## ----echo=TRUE, results=FALSE, warning=FALSE, message=FALSE-------------------
source("Progs/config.R")

## ----echo=FALSE---------------------------------------------------------------
knitr::read_chunk("Progs/config.R", labels = "config")

## ----config, eval=FALSE-------------------------------------------------------
# options(verbose = TRUE)
# 
# library_description()
# 
# # mylibs <- c("readxl", "dplyr", "ggplot2", "magrittr","tidyr","rmarkdown","knitr","xml2","rvest")
# #
# # for(package in mylibs){
# #   library(package, character.only = TRUE)
# # }
# 
# 
# # read in all function files
# my_functions <- list.files("Progs\\functions")
# for(file in my_functions){
#   if( file != "archive"){
#   source(paste0("Progs\\functions\\", file))
#   }
# }
# 
# # define theme for figures
# default_theme <- theme_get()
# 
# graphical_theme <- theme_bw() + theme(
#   axis.line.x      = element_line(color = "black"),
#   axis.line.y      = element_line(color = "black"),
#   panel.grid.major = element_blank() ,
#   panel.grid.minor = element_blank(),
#   panel.background = element_blank(),
#   # panel.border = element_blank(),
#   # axis.text = element_text(size = rel(1), angle = 45)
#   axis.title.x     = element_text(margin = margin(t = 10)),
#   legend.key       = element_rect(colour = "white", fill = NA),
#   strip.background = element_rect(colour = "black")
# )
# 
# # remove anything no longer required
# rm(mylibs, package, my_functions, file)

## ----echo=TRUE, results=FALSE, warning=FALSE, message=FALSE-------------------
source("Progs/data_import.R")

## ----echo=FALSE---------------------------------------------------------------
knitr::read_chunk("Progs/data_import.R", labels = "data_import")

## ----data_import, eval=FALSE--------------------------------------------------
# options(stringsAsFactors = FALSE)
# 
# data_table <- data.frame(
#   name=c("data","codes"),
#   file=c("dirtydata.csv",
#          "codes.csv"),
#   folder=system.file("extdata", package="cctu"),
#   stringsAsFactors = FALSE
# )
# 
# 
# read_data(data_table)
# read_data( data_table[2,])
# 
# # take an template meta table and add a new row with edited values.
# meta <- cctu::meta_table_example
# regress <- meta[1,]
# regress$title <- "Regression: Age predicted by Treatment"
# regress$number <- "1.2"
# meta <- rbind(meta, regress)
# 
# km <- meta[1,]
# km$title <- "Kaplan-Meier Plot"
# km$number <- "1.3"
# km$item <- "figure"
# meta <- rbind(meta, km)
# set_meta_table( meta)
# 
# 
# write_table(data_table_summary(data_table),number = "9", clean_up = FALSE)
# 
# 
# # Not strictly needed as the default is to apply these two functions inside of read_data(), but this
# # can be turned off with clean_names_option = FALSE , or remove_blank_rows_cols_option=FALSE
# data %<>% clean_names() %>% remove_blank_rows_cols()
# codes %<>% clean_names
# 
# 
# for( x in unique(codes$var)){
#   code_df <-  subset(codes, var==x)
#   print(code_df)
#   data[,x] <- factor( data[,x], levels=code_df$code, labels=code_df$label)
# }
# 
# data$start_date <- as.POSIXct( data$start_date , format="%d/%m/%Y")
# data_name <- names(data)
# names(data)[match("subject_id", data_name)] <- "subjid"
# 
# 
# 
# #Create the population table
# 
# popn <- data[,"subjid", drop=FALSE]
# popn$safety <- TRUE
# popn$full <- popn$subjid<5
# 
# create_popn_envir("data",popn)
# 
# #tidy up
# rm(code_df, codes, data_name, x)
# .reserved <- ls()

## ----echo=TRUE, results=FALSE, warning=FALSE, message=FALSE-------------------
source("Progs/analysis.R")

## ----echo=FALSE---------------------------------------------------------------
knitr::read_chunk("Progs/analysis.R", labels = "analysis")

## ----analysis, eval=FALSE-----------------------------------------------------
# attach_pop("1.1")
# X <- rbind_space(
#   sumby(age, treatment , data=data),
#   sumby(gender, treatment, data=data)
# )
# write_table(X)
# 
# attach_pop("1.1.1")
# X <- rbind_space(
#   sumby(age, treatment, data=data, label="aGe (yAars)", text_clean = NULL),
#   sumby(gender, treatment, data=data, text_clean = NULL)
# )
# write_table(X)
# 
# 
# attach_pop("1.10")
# X <- sumby(age, treatment, data=data)
# write_ggplot(attr(X,"fig"))
# 
# attach_pop("1.2")
# fit <- lm(age~treatment, data=data, na.action = na.omit)
# X <- regression_table(fit, labels = c("Mean age reference arm","Treament Effect"))
# #X <- sumby(age, treatment, data=data, label="aGe (yAars)", text_clean = NULL)
# write_table(X)
# 
# attach_pop("1.3")
# library(survival)
# fit <- survfit(Surv(time,status)~rx, data=colon)
# fig <- km_ggplot(fit)
# write_plot(fig)
# 
# attach_pop("2")
# write_text("There were no deaths")

## ----report-------------------------------------------------------------------
pop_size <- sapply(popn[, names(popn) != "subjid"], sum)
pop_name <- unique(get_meta_table()$population)
index <- match(pop_name, names(pop_size))
popn_labels <- paste0(propercase(pop_name), " (n = ", pop_size[index], ")")

write.csv(get_meta_table(), file = file.path("Output", "meta_table.csv"), row.names = FALSE)
write.csv(get_code_tree(), file = file.path("Output", "codetree.csv"), row.names = FALSE)
write_docx(
  report_title = "Vignette Report",
  author = "Simon Bond",
  filename = file.path("Output", "Reports", "Vignette_Report.doc"),
  popn_labels = popn_labels
)
Sys.info()
sessionInfo()
date()

## ----include=FALSE------------------------------------------------------------
# if(!dir.exists("../inst/doc")){dir.create("../inst/doc")}
# unlink("../inst/doc/Output", recursive=TRUE)
# file.copy("Output", "../inst/doc", recursive=TRUE)

## ----eval=FALSE---------------------------------------------------------------
# ctfile <- get_code_tree()
# pdf("codetree.pdf", width=13, height=7)
# plot(ctfile)
# dev.off()

